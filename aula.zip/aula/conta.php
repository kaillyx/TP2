<?php
session_start();
include 'includes/db.php';
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$usuario_id = $_SESSION['usuario_id'];
$sql = "SELECT nome, email FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $usuario = $result->fetch_assoc();
} else {
    echo "Usuário não encontrado!";
    exit();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'alterar_senha') {
            header("Location: senha.php");
            exit();
        } else if ($_POST['action'] === 'excluir_conta') {
            try {
                $sql = "DELETE FROM usuarios WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param('i', $usuario_id);
                $stmt->execute();
                session_destroy();
                header("Location: index.php");
                exit();
            } catch (PDOException $e) {
                echo "Erro ao excluir a conta: " . $e->getMessage();
            }
        } else if ($_POST['action'] === 'voltar') {
            header("Location: index.php");
            exit();
        }
    }
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minha Conta</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #e9ecef;
            margin: 0;
            padding: 0;
        }
        .header {
            text-align: center;
            padding: 20px;
            font-size: 24px;
            font-weight: bold;
            background-color: #ffffff;
            box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
        }
        .container {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            max-width: 1000px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.2);
        }
        .profile-info {
            flex: 1;
            font-size: 24px;
            margin-right: 20px;
            padding-top: 100px;
        }
        .profile-info p {
            margin: 20px 0;
            color: #495057;
        }
        .profile-info p strong {
            color: #007bff;
        }
        .profile-image img {
            max-width: 400px;
            height: auto;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }
        .button-group {
            text-align: center;
            margin-top: 20px;
        }
        .button-group form {
            display: inline-block;
            margin: 5px;
        }
        .button-group button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 14px 30px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s ease;
            margin: 5px;
            width: 200px;
        }
        .button-group button:hover {
            background-color: #0056b3;
        }
        .button-group button.delete {
            background-color: #dc3545;
        }
        .button-group button.delete:hover {
            background-color: #c82333;
        }
        .button-group button.back {
            background-color: #17a2b8;
        }
        .button-group button.back:hover {
            background-color: #138496;
        }
    </style>
</head>
<body>

    <div class="header">
        Sua Conta
    </div>

    <div class="container">
        <div class="profile-info">
            <p><strong>Bem-vindo, <?php echo htmlspecialchars($usuario['nome']); ?></strong></p>
            <p><strong>O que gostaria de Fazer?</strong></p>
        </div>
        <div class="profile-image">
            <img src="https://i.imgur.com/bN0ZgvU.png" alt="Imagem do Perfil">
        </div>
    </div>

    <div class="button-group">
        <form method="POST" action="">
            <button type="submit" name="action" value="alterar_senha">Alterar Senha</button>
        </form>
        <form method="POST" action="">
            <button type="submit" name="action" value="excluir_conta" class="delete">Excluir Conta</button>
        </form>
        <form method="POST" action="">
            <button type="submit" name="action" value="voltar" class="back">Voltar</button>
        </form>
    </div>

</body>
</html>
