<?php
session_start();
include '../includes/db.php';
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM produtos WHERE id = $id");
$produto = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $preco = $_POST['preco'];
    $categoria = $_POST['categoria'];
    $tamanho = $_POST['tamanho'];

    $sql = "UPDATE produtos 
            SET nome = '$nome', descricao = '$descricao', preco = $preco, categoria = '$categoria', tamanho = '$tamanho' 
            WHERE id = $id";
    if (!empty($_FILES['imagem']['name'])) {
        $imagem = $_FILES['imagem']['name'];
        $target = "../uploads/" . basename($imagem);
        move_uploaded_file($_FILES['imagem']['tmp_name'], $target);
        $sql = str_replace("WHERE id = $id", ", imagem = '$imagem' WHERE id = $id", $sql);
    }

    $conn->query($sql);
    header('Location: produtos.php');
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Produto</title>
   <style>
    /* admin.css */

/* Estilo geral */
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    color: #333;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px;
}

/* Título da página */
h1 {
    color: #007bff;
    margin-bottom: 20px;
    text-align: center;
    font-size: 24px;
}

/* Formulário */
form {
    width: 100%;
    max-width: 600px;
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

/* Rótulos */
form label {
    font-size: 14px;
    font-weight: bold;
    color: #555;
    display: block;
    margin-bottom: 5px;
}

/* Campos de entrada */
form input[type="text"],
form input[type="number"],
form input[type="file"],
form textarea {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ced4da;
    border-radius: 4px;
    font-size: 14px;
    color: #495057;
    box-sizing: border-box;
}

/* Área de texto */
form textarea {
    resize: vertical;
    min-height: 100px;
}

/* Campos ao passar o mouse */
form input[type="text"]:focus,
form input[type="number"]:focus,
form input[type="file"]:focus,
form textarea:focus {
    border-color: #007bff;
    outline: none;
}

/* Botão de submissão */
form button[type="submit"] {
    width: 100%;
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 12px;
    font-size: 16px;
    font-weight: bold;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s;
}

/* Botão ao passar o mouse */
form button[type="submit"]:hover {
    background-color: #0056b3;
}

    </style>
</head>
<body>
    <h1>Editar Produto</h1>
    <form method="post" enctype="multipart/form-data">
        <label>Nome:</label>
        <input type="text" name="nome" value="<?php echo $produto['nome']; ?>" required>
        <br>
        <label>Descrição:</label>
        <textarea name="descricao" required><?php echo $produto['descricao']; ?></textarea>
        <br>
        <label>Preço:</label>
        <input type="number" step="0.01" name="preco" value="<?php echo $produto['preco']; ?>" required>
        <br>
        <label>Categoria:</label>
        <input type="text" name="categoria" value="<?php echo $produto['categoria']; ?>" required>
        <br>
        <label>Tamanho:</label>
        <input type="text" name="tamanho" value="<?php echo $produto['tamanho']; ?>" required>
        <br>
        <label>Imagem (opcional):</label>
        <input type="file" name="imagem">
        <br>
        <button type="submit">Salvar</button>
    </form>
</body>
</html>
