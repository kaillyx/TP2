<?php
$host = 'localhost';
$user = 'root'; 
$password = ''; 
$dbname = 'loja_roupas'; 

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Erro ao conectar ao banco de dados: " . $conn->connect_error);
}
?>
