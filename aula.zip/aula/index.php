
<?php include 'includes/header.php';?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loja de Roupas</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

</head>
<body>
    <header>
        <h1>Bem-vindo à nossa loja!</h1>
        <p>Encontre as melhores tendências de moda para todas as estações e estilos.</p>
    </header>
 
    <div class="container">
        
        <section id="about">
            <h2>Sobre Nós</h2>
            <p>Somos uma loja especializada em moda de alta qualidade. Aqui, você encontra as últimas tendências para compor o seu guarda-roupa, com peças para todas as ocasiões.</p>
        </section>
        <section id="produtos">
            <h2>Produtos</h2>
            <div id="products-content">
                <div class="product-card">
                    <img src="uploads/br-11134207-7r98o-lvb2yb00b00o33 (1).jpg" alt="Produto 1">
                    <h3>Produto 1</h3>
                    <p>R$ 99,90</p>
                </div>
                <div class="product-card">
                    <img src="uploads/1878qw4er8qw-1000x1000 (1).jpg" alt="Produto 2">
                    <h3>Produto 2</h3>
                    <p>R$ 149,90</p>
                </div>
                <div class="product-card">
                    <img src="uploads/963422cdd600d5744a7bc4205d79b12d (1).jpg" alt="Produto 3">
                    <h3>Produto 3</h3>
                    <p>R$ 119,90</p>
                </div>
                <div class="product-card">
                    <img src="uploads/sg-11134201-22100-6jwj4ugdyajv26 (1).jpg" alt="Produto 4">
                    <h3>Produto 4</h3>
                    <p>R$ 79,90</p>
                </div>
            </div>
        </section>
        <section id="contact">
            <h2>Contato</h2>
            <p>Entre em contato conosco via e-mail ou venha nos visitar na nossa loja física.</p>
            <p>E-mail: contato@lojaderoupas.com</p>
        </section>
    </div>
    <footer>
    <p>&copy; 2024 Sua Empresa. Todos os direitos reservados.</p>
</footer>
</body>
</html>