<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Loja de Roupas</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <?php 
    include 'includes/header.php'; 
    include 'includes/db.php';

 
    $usuario_id = 1;
    $query = "SELECT c.quantidade, p.nome, p.preco 
              FROM carrinho c 
              JOIN produtos p ON c.produto_id = p.id 
              WHERE c.usuario_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $total_geral = 0;
    ?>

    <main class="container mt-5">
        <h1 class="text-center">Finalizar Compra</h1>
        <p class="text-center">
            Por favor, preencha as informações abaixo para concluir sua compra.
        </p>
        <section class="mb-5">
            <h2 class="mb-3">Resumo do Pedido</h2>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Produto</th>
                        <th>Quantidade</th>
                        <th>Preço Unitário</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($item = $result->fetch_assoc()) : ?>
                        <?php
                        $subtotal = $item['quantidade'] * $item['preco'];
                        $total_geral += $subtotal;
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['nome']); ?></td>
                            <td><?php echo htmlspecialchars($item['quantidade']); ?></td>
                            <td>R$ <?php echo number_format($item['preco'], 2, ',', '.'); ?></td>
                            <td>R$ <?php echo number_format($subtotal, 2, ',', '.'); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="3" class="text-end">Total Geral:</th>
                        <th>R$ <?php echo number_format($total_geral, 2, ',', '.'); ?></th>
                    </tr>
                </tfoot>
            </table>
        </section>

        <section>
            <h2 class="mb-3">Informações de Entrega</h2>
            <form action="confirmar_compra.php" method="post" class="needs-validation" novalidate>
                <div class="mb-3">
                    <label for="nome" class="form-label">Nome Completo</label>
                    <input type="text" id="nome" name="nome" class="form-control" placeholder="Digite seu nome completo" required>
                </div>

                <div class="mb-3">
                    <label for="endereco" class="form-label">Endereço</label>
                    <input type="text" id="endereco" name="endereco" class="form-control" placeholder="Digite seu endereço" required>
                </div>

                <div class="mb-3">
                    <label for="telefone" class="form-label">Telefone</label>
                    <input type="tel" id="telefone" name="telefone" class="form-control" placeholder="(xx) xxxxx-xxxx" required>
                </div>

                <div class="mb-3">
                    <label for="pagamento" class="form-label">Forma de Pagamento</label>
                    <select id="pagamento" name="pagamento" class="form-select" required>
                        <option value="" disabled selected>Selecione...</option>
                        <option value="cartao">Cartão de Crédito</option>
                        <option value="boleto">Boleto Bancário</option>
                        <option value="pix">Pix</option>
                    </select>
                </div>

                <div class="text-center">
                <form action="prototipo.php" method="get">
    <button type="submit" class="btn btn-success btn-lg">Confirmar Compra</button>
</form>
                </div>
            </form>     
        </section>
    </main>

    <?php include 'includes/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
