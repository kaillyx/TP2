<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre Nós - Loja de Roupas</title>
    <link rel="stylesheet" href="css/style.css"> 
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main>
        <h1>Sobre Nós</h1>
        <p>
            Bem-vindo à <strong>Loja de Roupas</strong>, onde moda e estilo se encontram! 
            Somos apaixonados por oferecer a melhor experiência de compras para nossos clientes, 
            com roupas modernas, de qualidade e acessíveis.
        </p>
        <p>
            Fundada em 2024, nossa missão é vestir pessoas de todos os estilos e idades, com peças 
            que traduzem conforto e personalidade. Trabalhamos com as melhores marcas e oferecemos 
            um atendimento diferenciado para que você se sinta confiante e satisfeito.
        </p>
        <p>
            <strong>Nosso compromisso:</strong>
            <ul>
                <li>Qualidade em cada produto.</li>
                <li>Preços competitivos.</li>
                <li>Entrega rápida e segura.</li>
                <li>Atendimento ao cliente dedicado.</li>
            </ul>
        </p>
    </main>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
